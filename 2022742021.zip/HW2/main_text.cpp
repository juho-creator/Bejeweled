#include "Puzzle.h"

#include <iostream>
#include <vector>
#include <string>

std::vector<std::string> predefined_puzzles = {
    "!#!&%*&@&!@&!!@#!@$$**%!&!&&!##&#*@$&@$%%$$*&*@$##$#@$%@#$&#%$@#",
    "#!%%@%!&@*%!&@&!#*$$%%%&#*$#@$@!$%$@%@&!%$&%&@*%*$&&*&#!$$&*$#*!",
    "*@&*@#%%&%%&   !$!*%#%*!*##*$$###*$$!#&&@*$$@#&#$&$$#!!!**@##@@@!!!",
    "$#@!%@$#$&$&!!*@@!$$@$!&*@**&$&@$!#*@&*@&###!@@%&@&!%&&%##$#@@&$",
};

std::string ascii = R"(
 ____      ____  ________  _____       ______    ___   ____    ____  ________   
|_  _|    |_  _||_   __  ||_   _|    .' ___  | .'   `.|_   \  /   _||_   __  |  
  \ \  /\  / /    | |_ \_|  | |     / .'   \_|/  .-.  \ |   \/   |    | |_ \_|  
   \ \/  \/ /     |  _| _   | |   _ | |       | |   | | | |\  /| |    |  _| _   
    \  /\  /     _| |__/ | _| |__/ |\ `.___.'\\  `-'  /_| |_\/_| |_  _| |__/ |  
     \/  \/     |________||________| `.____ .' `.___.'|_____||_____||________|  
                             _________    ___                                   
                            |  _   _  | .'   `.                                 
                            |_/ | | \_|/  .-.  \                                
                                | |    | |   | |                                
 __                   _        _| |_   \  `-'  /   __               __          
[  |                 (_)      |_____|   `.___.'   [  |             |  ]         
 | |.--.   .---.     __  .---.  _   _   __  .---.  | | .---.   .--.| |          
 | '/'`\ \/ /__\\   [  |/ /__\\[ \ [ \ [  ]/ /__\\ | |/ /__\\/ /'`\' |          
 |  \__/ || \__., _  | || \__., \ \/\ \/ / | \__., | || \__.,| \__/  |          
[__;.__.'  '.__.'[ \_| | '.__.'  \__/\__/   '.__.'[___]'.__.' '.__.;__]         
                  \____/                                                        
)";


/*
* Declare and define as many functions as necessary
*/

void start_screen();
bool play_game();
int select_menu();
bool check_choice(int choice);
Puzzle random_puzzle();
Puzzle select_puzzle();
bool play_game();

/*
* Implement text-based UI for playing Bejeweled game as required
*/




int main()
{
    bool playing = true;

    while (playing)
    {
        playing = play_game();
    }

    return 0;
}




bool play_game() {
    int choice;
    Puzzle puzzle(8, 8);
    bool wrong_input = true;

    // 1. Keep displaying game menu on wrong choice (Not within 1~3)
    while (wrong_input) {
        // Show Start Screen
        start_screen();

        // Get Menu choice from user
        choice = select_menu();

        // Check if choice is correct
        wrong_input = check_choice(choice);
    }

    // 2. Select Game Mode
    switch (choice) {
    case 1:
        puzzle = random_puzzle();
        break;
    case 2:
        puzzle = select_puzzle();
        break;
    case 3:
        return false;
    }



    // 3. Play game
    puzzle.printPuzzle(); // Display puzzle

    while (1) {
        std::pair<int, int> prev_loc, next_loc;

        // Remove all Chains by updating puzzle
        while (puzzle.update()) {
            std::cout << std::endl;

            // Print puzzle after each update
            puzzle.printPuzzle();
        }


        // Get move from user
        int r1, c1, r2, c2;
        std::cout << "Input the first swap position (row, col): ";
        std::cin >> r1 >> c1;
        prev_loc = std::make_pair(r1, c1);

        std::cout << "Input the second swap position (row, col): ";
        std::cin >> r2 >> c2;
        next_loc = std::make_pair(r2, c2);

        bool swapable = puzzle.swap(prev_loc, next_loc);


        if (swapable == true)
        {
            // Swap Input
            puzzle.swapJewels(prev_loc, next_loc);
            puzzle.printPuzzle();

            // Remove all Chains by updating puzzle
            while (puzzle.update()) {
                std::cout << std::endl;

                // Print puzzle after each update
                puzzle.printPuzzle();
            }
        }
        else {
            // Call play_game again
            return play_game();
        }
    }
}

    

void start_screen()
{
    std::cout << ascii << std::endl;
    std::cout << std::endl;

    std::cout << "[1] Start a new random puzzle" << std::endl;
    std::cout << "[2] Start a pre-defined puzzle" << std::endl;
    std::cout << "[3] Exit" << std::endl << std::endl;
}

int select_menu()
{
    int choice;
    std::cout << "> Choose a menu option (1~3): ";
    std::cin >> choice;
    return choice;
}

bool check_choice(int choice)
{
    if (1 <= choice && choice <= 3)
    {
        return false;
    }
    std::cout << std::endl;

}

Puzzle random_puzzle()
{
    // Create grid
    Puzzle puzzle(8, 8);

    // Add randomized puzzle
    puzzle.randomize();

    return puzzle;
}

Puzzle select_puzzle()
{
    int choice;

    // Create grid
    Puzzle puzzle(8, 8);

    // Ask user to choose puzzle
    std::cout << "> Choose a puzzle number (0~3): ";
    std::cin >> choice;

    // Select puzzle
    puzzle.initialize(predefined_puzzles[choice]);


    return puzzle;
}



