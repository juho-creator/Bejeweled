#include "Puzzle.h"
#include <iostream>

// For Jewel and Letter conversion
char Puzzle::getJewelLetter(Jewel jewel)
{
	char letter = ' ';

	switch (jewel) {
	case Jewel::NONE:	letter = ' ';	break;
	case Jewel::RED:	letter = '@';	break;
	case Jewel::ORANGE: letter = '#';	break;
	case Jewel::YELLOW: letter = '*';	break;
	case Jewel::GREEN:	letter = '%';	break;
	case Jewel::BLUE:	letter = '$';	break;
	case Jewel::PURPLE: letter = '&';	break;
	case Jewel::WHITE:	letter = '!';	break;
	}
	return letter;
}

Jewel Puzzle::getJewelType(char letter)
{
	Jewel jewel = Jewel::NONE;

	switch (letter) {
	case ' ':	jewel = Jewel::NONE;	break;
	case '@':	jewel = Jewel::RED;		break;
	case '#':	jewel = Jewel::ORANGE;	break;
	case '*':	jewel = Jewel::YELLOW;	break;
	case '%':	jewel = Jewel::GREEN;	break;
	case '$':	jewel = Jewel::BLUE;	break;
	case '&':	jewel = Jewel::PURPLE;	break;
	case '!':	jewel = Jewel::WHITE;	break;
	}
	return jewel;
}



// Create Puzzle (Grid) 
Puzzle::Puzzle(int rows, int columns)
{
	// Creating grid (rows x columns)
	grid.resize(rows, std::vector<Jewel>(columns, Jewel::NONE));

	// Set number of rows and columns
	num_rows = grid.size(); 
	num_columns = (num_rows > 0) ? grid[0].size() : 0; 
}



// Initialize Grid
bool Puzzle::initialize(const std::string& jewel_list)
{
	// Return False when jewel_list doesn't equal to number of Jewels
	if (jewel_list.size() != num_rows * num_columns) {
		return false;
	}


	// Add each Jewel to grid
	int index = 0;
	for (int i = 0; i < num_rows; ++i) {
		for (int j = 0; j < num_columns; ++j) {
			grid[i][j] = getJewelType(jewel_list[index]);
			++index;
		}
	}
	return true;
}



// Randomize Grid
void Puzzle::randomize() {
	for (int i = 0; i < num_rows; ++i) {
		for (int j = 0; j < num_columns; ++j) {
			// Generate a random number between 0 and 6 inclusive
			int random_number = rand() % 7; // 7 is the number of different Jewel enum values

			// Convert the random number to Jewel enum type
			grid[i][j] = static_cast<Jewel>(random_number);
		}
	}
}




// Remove chain & fill in gaps
void Puzzle::removeChains(const std::vector<Chain>& chains) {
	// Remove jewels in each chain
	for (const auto& chain : chains) {
		// Iterate over the cells in the chain
		for (int i = chain.start.first; i <= chain.end.first; ++i) {
			for (int j = chain.start.second; j <= chain.end.second; ++j) {
				// Set the jewel in the current cell to NONE
				grid[i][j] = Jewel::NONE;
			}
		}
	}
}




void Puzzle::fillGaps() {
	// Iterate through each column and row
	for (int j = 0; j < num_columns; ++j) {
		for (int i = num_rows - 1; i >= 0; --i) {
			
			// If empty Jewels are found
			if (grid[i][j] == Jewel::NONE) {
				int k = i - 1; // Initialize k to the row above the current cell
				while (k >= 0 && grid[k][j] == Jewel::NONE) { // Move upward until a non-empty cell is found or the top is reached
					--k;
				}
				if (k >= 0) { // If a non-empty cell is found above the current cell
					grid[i][j] = grid[k][j]; // Move the non-empty cell downward to fill the gap
					grid[k][j] = Jewel::NONE; // Set the original cell to empty
				}
				else {
					grid[i][j] = static_cast<Jewel>(rand() % 7); // If no non-empty cell is found above, generate a random jewel to fill the gap
				}
			}
		}
	}
}


bool Puzzle::update() {
	static bool apply_rule_A = true; // Alternate between rule A and rule B

	if (apply_rule_A) {
		// Rule A: Identify and remove chains
		auto chains = findChains();
		if (!chains.empty()) {
			removeChains(chains);
			apply_rule_A = false;
			return true;
		}
	}
	else {
		// Rule B: Fill gaps
		fillGaps();
		apply_rule_A = true;
		return true;
	}

	// No more updates allowed
	return false;
}


std::vector<Puzzle::Chain> Puzzle::findChains() {
	std::vector<Chain> chains;

	// Horizontal chains
	for (int i = 0; i < num_rows; ++i) {
		int chain_length = 1;
		Jewel current_jewel = grid[i][0];
		std::pair<int, int> chain_start = { i, 0 };

		for (int j = 1; j < num_columns; ++j) {
			if (grid[i][j] == current_jewel) {
				++chain_length;
			}
			else {
				if (chain_length >= 3) {
					Chain chain;
					chain.jewel = current_jewel;
					chain.start = chain_start;
					chain.end = { i, j - 1 };
					chains.push_back(chain);
				}

				current_jewel = grid[i][j];
				chain_start = { i, j };
				chain_length = 1;
			}
		}

		if (chain_length >= 3) {
			Chain chain;
			chain.jewel = current_jewel;
			chain.start = chain_start;
			chain.end = { i, num_columns - 1 };
			chains.push_back(chain);
		}
	}

	// Vertical chains
	for (int j = 0; j < num_columns; ++j) {
		int chain_length = 1;
		Jewel current_jewel = grid[0][j];
		std::pair<int, int> chain_start = { 0, j };

		for (int i = 1; i < num_rows; ++i) {
			if (grid[i][j] == current_jewel) {
				++chain_length;
			}
			else {
				if (chain_length >= 3) {
					Chain chain;
					chain.jewel = current_jewel;
					chain.start = chain_start;
					chain.end = { i - 1, j };
					chains.push_back(chain);
				}

				current_jewel = grid[i][j];
				chain_start = { i, j };
				chain_length = 1;
			}
		}

		if (chain_length >= 3) {
			Chain chain;
			chain.jewel = current_jewel;
			chain.start = chain_start;
			chain.end = { num_rows - 1, j };
			chains.push_back(chain);
		}
	}

	return chains;
}


bool Puzzle::setJewel(std::pair<int, int> loc, Jewel jewel) {
	// Check if loc is a valid location
	if (loc.first >= 0 && loc.first < num_rows && loc.second >= 0 && loc.second < num_columns) {
		// Set the jewel at the specified location
		grid[loc.first][loc.second] = jewel;
		return true; // Return true indicating success
	}
	else {
		return false; // Return false if loc is not a valid location
	}
}


Jewel Puzzle::getJewel(std::pair<int, int> loc) const {
	// Check if loc is a valid location
	if (loc.first >= 0 && loc.first < num_rows && loc.second >= 0 && loc.second < num_columns) {
		// Return the jewel at the specified location
		return grid[loc.first][loc.second];
	}
	else {
		// Return Jewel::NONE if loc is not a valid location
		return Jewel::NONE;
	}
}

bool Puzzle::swapJewels(std::pair<int, int> prev_loc, std::pair<int, int> next_loc) {
	// Check if both prev_loc and next_loc are valid locations
	if (prev_loc.first >= 0 && prev_loc.first < num_rows && prev_loc.second >= 0 && prev_loc.second < num_columns &&
		next_loc.first >= 0 && next_loc.first < num_rows && next_loc.second >= 0 && next_loc.second < num_columns) {

		// Check if prev_loc and next_loc are adjacent (horizontally or vertically)
		if ((std::abs(prev_loc.first - next_loc.first) == 1 && prev_loc.second == next_loc.second) ||
			(std::abs(prev_loc.second - next_loc.second) == 1 && prev_loc.first == next_loc.first)) {

			// Get the jewels at prev_loc and next_loc
			Jewel jA = grid[prev_loc.first][prev_loc.second];
			Jewel jB = grid[next_loc.first][next_loc.second];

			// Swap the jewels at prev_loc and next_loc
			grid[prev_loc.first][prev_loc.second] = jB;
			grid[next_loc.first][next_loc.second] = jA;

			return true; // Return true indicating successful swap
		}
	}

	return false; // Return false if conditions are not met
}



void Puzzle::printPuzzle() const {
	std::cout << std::endl;

	std::cout << "   ";
	for (int j = 0; j < num_columns; ++j) {
		std::cout << j << " ";
	}
	std::cout << std::endl;
	std::cout << "   +--------------" << std::endl;

	for (int i = 0; i < num_rows; ++i) {
		std::cout << i << " |";
		for (int j = 0; j < num_columns; ++j) {
			std::cout << getJewelLetter(grid[i][j]) << " ";
		}
		std::cout << std::endl;
	}
	std::cout << std::endl;

}

bool Puzzle::swap(std::pair<int, int> prev_loc, std::pair<int, int> next_loc)
{
	// Check if both positions are (0,0)
	if (prev_loc == next_loc && prev_loc.first == 0 && prev_loc.second == 0) {
		std::cout << std::endl << std::endl << std::endl;
		return false;
	}
	return true;
}